import tkinter as tk
import requests

# Función para enviar el comando al ESP32
def send_command():
    esp32_ip = ip_entry.get()  # Obtener la IP ingresada
    command = command_entry.get()  # Obtener el comando ingresado
    try:
        # Intentar enviar el comando al ESP32 a través de HTTP
        response = requests.post(f'http://{esp32_ip}/command', data={'command': command})
        if response.status_code == 200:
            result_label.config(text=f"Comando '{command}' enviado correctamente.")
        else:
            result_label.config(text="Error al enviar el comando.")
    except requests.exceptions.RequestException as e:
        result_label.config(text=f"Error de conexión: {str(e)}")

# Crear la ventana principal
root = tk.Tk()
root.title("Control ESP32")  # Título de la ventana

# Crear etiquetas y campos de entrada
tk.Label(root, text="IP del ESP32:").pack(pady=5)  # Etiqueta para IP
ip_entry = tk.Entry(root)  # Campo de texto para la IP
ip_entry.pack(pady=5)
ip_entry.insert(0, "192.168.4.1")  # Valor por defecto (ajustar según el monitor serial)

tk.Label(root, text="Comando:").pack(pady=5)  # Etiqueta para comando
command_entry = tk.Entry(root)  # Campo de texto para el comando
command_entry.pack(pady=5)

# Crear el botón para enviar el comando
send_button = tk.Button(root, text="Enviar Comando", command=send_command)
send_button.pack(pady=10)

# Crear una etiqueta para mostrar los resultados
result_label = tk.Label(root, text="", fg="green")
result_label.pack(pady=5)

# Iniciar la aplicación
root.mainloop()
