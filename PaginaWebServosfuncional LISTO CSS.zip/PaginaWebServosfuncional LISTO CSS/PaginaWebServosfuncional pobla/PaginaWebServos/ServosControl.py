import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
import requests
import threading  # Importar threading para usar hilos

# Función para conectar al ESP32 (se ejecuta en un hilo separado)
def connect_esp32():
    esp32_ip = ip_entry.get()  # Obtener la IP ingresada
    status_label.config(text="Buscando ESP32...", fg="blue")  # Cambiar texto a "Buscando ESP32" en azul
    try:
        # Intentar realizar una petición de prueba al ESP32 para verificar la conexión
        response = requests.get(f'http://{esp32_ip}/status', timeout=5)  # Agregar un tiempo de espera (timeout)
        if response.status_code == 200:
            status_label.config(text="Conectado a ESP32", fg="green")  # Conexión exitosa, texto en verde
        else:
            status_label.config(text="Conexión fallida", fg="red")  # Fallo en la conexión, texto en rojo
    except requests.exceptions.RequestException as e:
        # Mostrar mensaje más corto en caso de error
        status_label.config(text="Error al conectar", fg="red")  # Error en la conexión, texto en rojo

# Función para ejecutar la conexión en un hilo separado
def connect_esp32_thread():
    # Ejecutar la función de conexión sin bloquear la GUI
    threading.Thread(target=connect_esp32).start()

# Crear la ventana principal
root = tk.Tk()
root.title("Control de Servos")

# Establecer el tamaño de la ventana al tamaño completo, pero con los controles de la ventana visibles
root.state('normal')  # Esto asegura que los controles de la ventana estén disponibles
root.geometry("1920x1080")  # Esto asegura que la ventana ocupe todo el tamaño de la pantalla

# Variables para el estado de los servos y parámetros
estado_ejecucion = "Listo"
paso_actual = 0

# Función para cambiar el estado
def update_status():
    estado_label.config(text=f"Estado de Ejecución: {estado_ejecucion}")
    paso_label.config(text=f"Paso Actual: {paso_actual}")

# Función para cambiar entre pestañas
def open_tab(tab_name):
    # Ocultar todas las pestañas
    for tab in tabs:
        tab_frames[tab].pack_forget()

    # Mostrar la pestaña seleccionada
    tab_frames[tab_name].pack(fill="both", expand=True)

# Función para simular el envío de comando a servos
def send_command_servo(servo):
    messagebox.showinfo("Comando", f"Movimiento enviado al Servo {servo}")

# Función para simular agregar un punto
def add_point(servo):
    # Agregar el punto a la tabla correspondiente
    if servo == 1:
        position = servo1_position.get()
        table1.insert('', 'end', values=(position,))
        servo1_position.delete(0, 'end')  # Limpiar el campo después de agregar
    elif servo == 2:
        position = servo2_position.get()
        table2.insert('', 'end', values=(position,))
        servo2_position.delete(0, 'end')  # Limpiar el campo después de agregar
    elif servo == 3:
        position = servo3_position.get()
        table3.insert('', 'end', values=(position,))
        servo3_position.delete(0, 'end')  # Limpiar el campo después de agregar
    elif servo == 4:
        position = servo4_position.get()
        table4.insert('', 'end', values=(position,))
        servo4_position.delete(0, 'end')  # Limpiar el campo después de agregar
    messagebox.showinfo("Comando", f"Punto agregado para el Servo {servo}")

# Función para ejecutar la secuencia alternada
def execute_sequence():
    messagebox.showinfo("Ejecutar Secuencia", "Ejecutando secuencia alternada...")
    # Limpiar todas las tablas al ejecutar la secuencia
    table1.delete(*table1.get_children())
    table2.delete(*table2.get_children())
    table3.delete(*table3.get_children())
    table4.delete(*table4.get_children())

# Crear las pestañas
tabs = ["pestana1", "pestana2", "pestana3", "pestana4", "pestana5"]
tab_frames = {}

# Frame principal
frame_main = tk.Frame(root)
frame_main.grid(row=0, column=0, sticky="nsew")  # Esto asegura que el contenido principal ocupe toda la izquierda

# Agregar Canvas y Scrollbar
canvas = tk.Canvas(frame_main)
scrollbar = tk.Scrollbar(frame_main, orient="vertical", command=canvas.yview)
canvas.configure(yscrollcommand=scrollbar.set)

# Empaquetar el Canvas y Scrollbar sin espacio en blanco extra
canvas.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")

# Crear un frame que contendrá todo el contenido que será desplazable
frame_content = tk.Frame(canvas)
canvas.create_window((0, 0), window=frame_content, anchor="nw")

# Eliminar el espacio vacío a la derecha asegurando que el contenido se ajuste a todo el canvas
frame_content.update_idletasks()
canvas.config(scrollregion=canvas.bbox("all"))

# Crear la caja de estado de ejecución
frame_content.pack(fill="both", expand=True)  # Asegúrate de que el frame_content ocupe todo el espacio disponible

status_box = tk.LabelFrame(frame_content, text="Estado de Ejecución", padx=10, pady=10)
status_box.pack(fill="x", padx=10, pady=5)  # Esto asegurará que el LabelFrame se expanda horizontalmente
estado_label = tk.Label(status_box, text=f"Estado de Ejecución: {estado_ejecucion}")
estado_label.pack()
paso_label = tk.Label(status_box, text=f"Paso Actual: {paso_actual}")
paso_label.pack()

# Crear los botones para las pestañas con un tamaño mayor
tab_container = tk.Frame(frame_content)
tab_container.pack(fill="x", pady=10)

button_tab1 = tk.Button(tab_container, text="Servo 1", width=15, height=2, command=lambda: open_tab("pestana1"))
button_tab1.pack(side="left", padx=5)
button_tab2 = tk.Button(tab_container, text="Servo 2", width=15, height=2, command=lambda: open_tab("pestana2"))
button_tab2.pack(side="left", padx=5)
button_tab3 = tk.Button(tab_container, text="Servo 3", width=15, height=2, command=lambda: open_tab("pestana3"))
button_tab3.pack(side="left", padx=5)
button_tab4 = tk.Button(tab_container, text="Servo 4", width=15, height=2, command=lambda: open_tab("pestana4"))
button_tab4.pack(side="left", padx=5)
button_tab5 = tk.Button(tab_container, text="Configuración", width=15, height=2, command=lambda: open_tab("pestana5"))
button_tab5.pack(side="left", padx=5)

# Crear los contenidos de las pestañas
for tab in tabs:
    tab_frames[tab] = tk.Frame(frame_content)

# Pestaña 1 (Servo 1)
frame_servo1 = tab_frames["pestana1"]
tk.Label(frame_servo1, text="Servo 1", font=("Arial", 14, "bold")).grid(row=0, column=0, pady=10, columnspan=2)

# Movimiento Inmediato
tk.Label(frame_servo1, text="Movimiento Inmediato").grid(row=1, column=0, sticky="w")
servo1_value = tk.Entry(frame_servo1)
servo1_value.grid(row=2, column=0, pady=5)

servo1_move_button = tk.Button(frame_servo1, text="Mover", command=lambda: send_command_servo(1))
servo1_move_button.grid(row=3, column=0, pady=5)

# Configuración Trayectoria
tk.Label(frame_servo1, text="Configuración Trayectoria").grid(row=4, column=0, pady=10)
servo1_position = tk.Entry(frame_servo1)
servo1_position.grid(row=5, column=0, pady=5)

servo1_add_point_button = tk.Button(frame_servo1, text="Punto Agregado", command=lambda: add_point(1))
servo1_add_point_button.grid(row=6, column=0, pady=5)

# Parámetros PID
tk.Label(frame_servo1, text="Parámetros PID", font=("Arial", 12, "bold")).grid(row=7, column=0, pady=10)
tk.Label(frame_servo1, text="P: ").grid(row=8, column=0, sticky="w")
servo1_p = tk.Entry(frame_servo1)
servo1_p.grid(row=9, column=0, pady=5)

tk.Label(frame_servo1, text="I: ").grid(row=10, column=0, sticky="w")
servo1_i = tk.Entry(frame_servo1)
servo1_i.grid(row=11, column=0, pady=5)

tk.Label(frame_servo1, text="D: ").grid(row=12, column=0, sticky="w")
servo1_d = tk.Entry(frame_servo1)
servo1_d.grid(row=13, column=0, pady=5)

# Movimiento
tk.Label(frame_servo1, text="Movimiento", font=("Arial", 12, "bold")).grid(row=14, column=0, pady=10)
tk.Label(frame_servo1, text="Velocidad: ").grid(row=15, column=0, sticky="w")
servo1_velocity = tk.Entry(frame_servo1)
servo1_velocity.grid(row=16, column=0, pady=5)

tk.Label(frame_servo1, text="Aceleración: ").grid(row=17, column=0, sticky="w")
servo1_acceleration = tk.Entry(frame_servo1)
servo1_acceleration.grid(row=18, column=0, pady=5)

servo1_set_params_button = tk.Button(frame_servo1, text="Cambiar Parámetros", command=lambda: send_command_servo(1))
servo1_set_params_button.grid(row=19, column=0, pady=10)

# Crear la tabla para mostrar los puntos del Servo 1 (ubicada a la derecha)
table1 = ttk.Treeview(frame_servo1, columns=("Posición"))
table1.heading("#1", text="Posición")
table1.grid(row=1, column=1, rowspan=19, padx=10)

# Pestaña 2 (Servo 2)
frame_servo2 = tab_frames["pestana2"]
tk.Label(frame_servo2, text="Servo 2", font=("Arial", 14, "bold")).grid(row=0, column=0, pady=10, columnspan=2)

# Movimiento Inmediato
tk.Label(frame_servo2, text="Movimiento Inmediato").grid(row=1, column=0, sticky="w")
servo2_value = tk.Entry(frame_servo2)
servo2_value.grid(row=2, column=0, pady=5)

servo2_move_button = tk.Button(frame_servo2, text="Mover", command=lambda: send_command_servo(2))
servo2_move_button.grid(row=3, column=0, pady=5)

# Configuración Trayectoria
tk.Label(frame_servo2, text="Configuración Trayectoria").grid(row=4, column=0, pady=10)
servo2_position = tk.Entry(frame_servo2)
servo2_position.grid(row=5, column=0, pady=5)

servo2_add_point_button = tk.Button(frame_servo2, text="Punto Agregado", command=lambda: add_point(2))
servo2_add_point_button.grid(row=6, column=0, pady=5)


# Parámetros PID
tk.Label(frame_servo2, text="Parámetros PID", font=("Arial", 12, "bold")).grid(row=7, column=0, pady=10)
tk.Label(frame_servo2, text="P: ").grid(row=8, column=0, sticky="w")
servo2_p = tk.Entry(frame_servo2)
servo2_p.grid(row=9, column=0, pady=5)

tk.Label(frame_servo2, text="I: ").grid(row=10, column=0, sticky="w")
servo2_i = tk.Entry(frame_servo2)
servo2_i.grid(row=11, column=0, pady=5)

tk.Label(frame_servo2, text="D: ").grid(row=12, column=0, sticky="w")
servo2_d = tk.Entry(frame_servo2)
servo2_d.grid(row=13, column=0, pady=5)

# Movimiento
tk.Label(frame_servo2, text="Movimiento", font=("Arial", 12, "bold")).grid(row=14, column=0, pady=10)
tk.Label(frame_servo2, text="Velocidad: ").grid(row=15, column=0, sticky="w")
servo2_velocity = tk.Entry(frame_servo2)
servo2_velocity.grid(row=16, column=0, pady=5)

tk.Label(frame_servo2, text="Aceleración: ").grid(row=17, column=0, sticky="w")
servo2_acceleration = tk.Entry(frame_servo2)
servo2_acceleration.grid(row=18, column=0, pady=5)

servo2_set_params_button = tk.Button(frame_servo2, text="Cambiar Parámetros", command=lambda: send_command_servo(1))
servo2_set_params_button.grid(row=19, column=0, pady=10)

# Crear la tabla para mostrar los puntos del Servo 2 (ubicada a la derecha)
table2 = ttk.Treeview(frame_servo2, columns=("Posición"))
table2.heading("#1", text="Posición")
table2.grid(row=1, column=1, rowspan=19, padx=10)

# Pestaña 3 (Servo 3)
frame_servo3 = tab_frames["pestana3"]
tk.Label(frame_servo3, text="Servo 3", font=("Arial", 14, "bold")).grid(row=0, column=0, pady=10, columnspan=2)

# Movimiento Inmediato
tk.Label(frame_servo3, text="Movimiento Inmediato").grid(row=1, column=0, sticky="w")
servo3_value = tk.Entry(frame_servo3)
servo3_value.grid(row=2, column=0, pady=5)

servo3_move_button = tk.Button(frame_servo3, text="Mover", command=lambda: send_command_servo(3))
servo3_move_button.grid(row=3, column=0, pady=5)

# Configuración Trayectoria
tk.Label(frame_servo3, text="Configuración Trayectoria").grid(row=4, column=0, pady=10)
servo3_position = tk.Entry(frame_servo3)
servo3_position.grid(row=5, column=0, pady=5)

servo3_add_point_button = tk.Button(frame_servo3, text="Punto Agregado", command=lambda: add_point(3))
servo3_add_point_button.grid(row=6, column=0, pady=5)
# Parámetros PID
tk.Label(frame_servo3, text="Parámetros PID", font=("Arial", 12, "bold")).grid(row=7, column=0, pady=10)
tk.Label(frame_servo3, text="P: ").grid(row=8, column=0, sticky="w")
servo3_p = tk.Entry(frame_servo3)
servo3_p.grid(row=9, column=0, pady=5)

tk.Label(frame_servo3, text="I: ").grid(row=10, column=0, sticky="w")
servo3_i = tk.Entry(frame_servo3)
servo3_i.grid(row=11, column=0, pady=5)

tk.Label(frame_servo3, text="D: ").grid(row=12, column=0, sticky="w")
servo3_d = tk.Entry(frame_servo3)
servo3_d.grid(row=13, column=0, pady=5)

# Movimiento
tk.Label(frame_servo3, text="Movimiento", font=("Arial", 12, "bold")).grid(row=14, column=0, pady=10)
tk.Label(frame_servo3, text="Velocidad: ").grid(row=15, column=0, sticky="w")
servo3_velocity = tk.Entry(frame_servo3)
servo3_velocity.grid(row=16, column=0, pady=5)

tk.Label(frame_servo3, text="Aceleración: ").grid(row=17, column=0, sticky="w")
servo3_acceleration = tk.Entry(frame_servo3)
servo3_acceleration.grid(row=18, column=0, pady=5)

servo3_set_params_button = tk.Button(frame_servo3, text="Cambiar Parámetros", command=lambda: send_command_servo(1))
servo3_set_params_button.grid(row=19, column=0, pady=10)

# Crear la tabla para mostrar los puntos del Servo 3 (ubicada a la derecha)
table3 = ttk.Treeview(frame_servo3, columns=("Posición"))
table3.heading("#1", text="Posición")
table3.grid(row=1, column=1, rowspan=19, padx=10)

# Pestaña 4 (Servo 4)
frame_servo4 = tab_frames["pestana4"]
tk.Label(frame_servo4, text="Servo 4", font=("Arial", 14, "bold")).grid(row=0, column=0, pady=10, columnspan=2)

# Movimiento Inmediato
tk.Label(frame_servo4, text="Movimiento Inmediato").grid(row=1, column=0, sticky="w")
servo4_value = tk.Entry(frame_servo4)
servo4_value.grid(row=2, column=0, pady=5)

servo4_move_button = tk.Button(frame_servo4, text="Mover", command=lambda: send_command_servo(2))
servo4_move_button.grid(row=3, column=0, pady=5)

# Configuración Trayectoria
tk.Label(frame_servo4, text="Configuración Trayectoria").grid(row=4, column=0, pady=10)
servo4_position = tk.Entry(frame_servo4)
servo4_position.grid(row=5, column=0, pady=5)

servo4_add_point_button = tk.Button(frame_servo4, text="Punto Agregado", command=lambda: add_point(2))
servo4_add_point_button.grid(row=6, column=0, pady=5)


# Crear la tabla para mostrar los puntos del Servo 4 (ubicada a la derecha)
table4 = ttk.Treeview(frame_servo4, columns=("Posición"))
table4.heading("#1", text="Posición")
table4.grid(row=1, column=1, rowspan=19, padx=10)

# Pestaña 5 (Configuración) - Agregando el código para enviar comando al ESP32
frame_config = tab_frames["pestana5"]
tk.Label(frame_config, text="Configuración del ESP32", font=("Arial", 14, "bold")).grid(row=0, column=0, pady=10, columnspan=2)

# IP del ESP32
tk.Label(frame_config, text="IP del ESP32:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
ip_entry = tk.Entry(frame_config)  # Campo de texto para la IP
ip_entry.grid(row=1, column=1, pady=5)
ip_entry.insert(0, "192.168.4.1")  # Valor por defecto

# Crear el botón para conectar al ESP32
connect_button = tk.Button(frame_config, text="Conectar", command=connect_esp32_thread)
connect_button.grid(row=2, column=0, columnspan=2, pady=10)

# Crear una etiqueta para mostrar el estado de la conexión
status_label = tk.Label(frame_config, text="Estado de conexión: Desconectado", fg="orange")
status_label.grid(row=3, column=0, columnspan=2, pady=5)

# **Nueva sección fija (siempre visible)**

# Frame para la parte fija (lado derecho)
frame_fixed = tk.Frame(root)
frame_fixed.grid(row=0, column=1, sticky="ns")  # Se coloca en la columna 1, al lado derecho del grid principal
frame_fixed.grid_rowconfigure(0, weight=1)

# Sección fija de "Otra Configuración"
tk.Label(frame_fixed, text="Otra Configuración", font=("Arial", 12, "bold")).grid(row=0, column=0, padx=5, pady=5)
other_entry = tk.Entry(frame_fixed)
other_entry.grid(row=1, column=0, padx=5, pady=5)

other_button = tk.Button(frame_fixed, text="Hacer algo", command=lambda: messagebox.showinfo("Acción", "Acción ejecutada"))
other_button.grid(row=2, column=0, padx=5, pady=5)

# Botón para ejecutar secuencia
execute_button = tk.Button(frame_fixed, text="Ejecutar Secuencia Alternada", command=execute_sequence)
execute_button.grid(row=3, column=0, padx=5, pady=10)

# Establecer las proporciones de los grid
root.grid_columnconfigure(0, weight=1)  # Asegura que la columna 0 (izquierda) ocupe más espacio
root.grid_columnconfigure(1, weight=2)  # La columna 1 (derecha) tendrá menos espacio, pero será flexible

# Inicializar la primera pestaña
open_tab("pestana1")

# Actualizar el estado cada segundo
update_status()

# Configurar el scroll
frame_content.update_idletasks()
canvas.config(scrollregion=canvas.bbox("all"))

# Iniciar la aplicación
root.mainloop()
